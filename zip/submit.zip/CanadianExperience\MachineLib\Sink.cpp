/**
 * \file Sink.cpp
 *
 * \author Elizabeth Stevens
 */

#include "pch.h"
#include "Sink.h"
#include "Source.h"
#include "Component.h"

/** Constructor */
CSink::CSink()
{
}

/** Destructor */
CSink::~CSink()
{
}
